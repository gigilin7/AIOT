# flask-highcharts

Tutorial:

- Fetch data from https://www.blockchain.com/
- Data preprocessing in Flask and parse to Highcharts
- Deploy to Heroku

Live demo: [https://flask-highcharts.herokuapp.com/](https://flask-highcharts.herokuapp.com/)

![https://vuongvtrinh.github.io/post/data-analytics-dashboard/screenshot.png](https://vuongvtrinh.github.io/post/data-analytics-dashboard/screenshot.png)
